## Express JS Node JS Complete Authentication API

## To Run this Project via NPM follow below:

```bash
npm install
npm run dev
```

#### There is a Folder "PostmanEndpoints" which has Postman Collection File You can import this file in your postman to test this API

